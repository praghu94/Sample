// editor with syntax hilighting is recommended (for example, notepad++ or textmate)

accounts = {

// Put your data here as shown below. Don't forget the commas and quotes!
// If your emails or passwords contain single quotes,
// escape them with backslashes (\) like this: 'pass\'word'


'email': 'pass',
'email2': 'pass2',


}// don't delete this line!


// how many characters are displayed in each row (within one account)
rowlength = 7

// change to 1 to switch to testing
testing = 0

// change to 1 to enable price display in tooltips
prices = 0

// change to 1 to enable one-click login (run lib/mulelogin.au3 first)
mulelogin = 0

// 0 = use smart layout (fill empty spaces)
// 1 = show account boxes row by row
nomasonry = 0
